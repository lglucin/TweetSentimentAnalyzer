READ=False
trainExamples=[]